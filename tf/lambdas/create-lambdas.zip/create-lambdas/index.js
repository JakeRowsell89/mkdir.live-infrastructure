exports.handler = async (event) => {
    
    return {
        statusCode: 200,
        body: 'some result from generating functions'
    }
}